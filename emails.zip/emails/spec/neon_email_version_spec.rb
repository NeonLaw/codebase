RSpec.describe NeonEmail do
  it "has a version number" do
    expect(NeonEmail::VERSION).not_to be nil
  end
end
